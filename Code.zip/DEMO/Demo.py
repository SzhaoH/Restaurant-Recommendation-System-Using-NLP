import streamlit as st 
from streamlit_folium import folium_static
import folium
import numpy as np
import pandas as pd
import seaborn as sb
import matplotlib.pyplot as plt
import plotly.offline as py
import plotly.graph_objs as go
import seaborn as sns
import warnings
from pandas import option_context
warnings.filterwarnings('always')
warnings.filterwarnings('ignore')
import pickle
from st_aggrid import AgGrid
#EDA code

df_percent =pd.read_csv('FYP2_CLEAN_ALL_FOOD.csv')
bert_vec = pickle.load(open("BERT_cosine.pkl", 'rb'))
#-----------------------------------------------------------------------------------#
st.set_page_config(layout="wide")
text1 = '<p style="font-family:Time-New-Roman; font-size: 32px;font-weight: bold;">Restaurant Recommendation System Using NLP</p>' 
st.markdown(text1, unsafe_allow_html=True)
text2 = '<p style="font-family:Time-New-Roman; font-size: 15px;font-weight: bold;">Example Input: North Indian, Continental, Italian</p>'
st.markdown(text2, unsafe_allow_html=True)
sentence = st.text_input('Input cuisine of the restaurant that you like:') 



def recommend(name,cosine_similarities):
   
    recommend_restaurant = []
    
    # Find the index of the restaurant entered
    df = df_percent.sort_values(by='Mean Rating', ascending=False)
    try:
        idx=df.index[df['cuisines']==name][0]
        # Find the restaurants with a similar cosine-sim value and order them from bigges number
        score_series = pd.Series(cosine_similarities[idx]).sort_values(ascending=False)
        # Extract top 100 restaurant indexes with a similar cosine-sim value
        top100_indexes = list(score_series.iloc[0:100].index)
        # Names of the top 100 restaurants
        for each in top100_indexes:
            recommend_restaurant.append(list(df_percent.index)[each])       
        # Creating the new data set to show similar restaurants
        df_new = pd.DataFrame(columns=['cuisines','Restaurant_Name','address','Rating','Service','Recommended','Not Recommended'])
        for each in recommend_restaurant:
            df_new = df_new.append(pd.DataFrame(df_percent[['cuisines','Restaurant_Name','address','Rating','Service','Recommended','Not Recommended']][df_percent.index == each].sample()))
        #df_new['score'] =list(score_series.iloc[0:100])
        df_new = df_new.drop_duplicates(subset=['Restaurant_Name'])

        title6 = '<p style="font-family:Time-New-Roman; font-size: 15px;font-weight: bold">TOP 10 RESTAURANTS LIKE WITH SIMILAR REVIEWS:</p>'
        st.markdown(title6, unsafe_allow_html=True)       
        AgGrid(df_new.head(10))




    except Exception :
        title6 = '<p style="font-family:Time-New-Roman; font-size: 18px;font-weight: bold">.</p>'
        st.markdown(title6, unsafe_allow_html=True)
        title6 = '<p style="font-family:Time-New-Roman; font-size: 18px;font-weight: bold">..</p>'
        st.markdown(title6, unsafe_allow_html=True)
        title6 = '<p style="font-family:Time-New-Roman; font-size: 18px;font-weight: bold">...</p>'
        st.markdown(title6, unsafe_allow_html=True)
        title6 = '<p style="font-family:Time-New-Roman; font-size: 18px;font-weight: bold">SORRY, THERE ARE NO RELEVANT RESTAURANT</p>'
        st.markdown(title6, unsafe_allow_html=True)
        title6 = '<p style="font-family:Time-New-Roman; font-size: 18px;font-weight: bold">.</p>'
        st.markdown(title6, unsafe_allow_html=True)
        title6 = '<p style="font-family:Time-New-Roman; font-size: 18px;font-weight: bold">..</p>'
        st.markdown(title6, unsafe_allow_html=True)
        title6 = '<p style="font-family:Time-New-Roman; font-size: 18px;font-weight: bold">...</p>'
        st.markdown(title6, unsafe_allow_html=True)

    

    
if sentence:
    st.write(recommend(sentence,bert_vec))
    
title6 = '<p style="font-family:Time-New-Roman; font-size: 18px;font-weight: bold">End of content.</p>' 
st.markdown(title6, unsafe_allow_html=True)
title6 = '<p style="font-family:Time-New-Roman; font-size: 15px;font-weight: bold">Prepared by Soe Zhao Hong(1181101614)</p>' 
st.markdown(title6, unsafe_allow_html=True)
